package com.cacaaoalvo.jogo;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.view.*;
import android.widget.*;
import java.util.Random;

public class MainActivity extends Activity {
    GameView game;
    @Override public void onCreate(Bundle b){ super.onCreate(b); game=new GameView(this); setContentView(game); }

    class GameView extends View {
        Paint p=new Paint(1); Random rnd=new Random();
        int score=0,time=30,best; float tx,ty; boolean playing=false;
        long lastSecond=0;

        GameView(Context c){ super(c); best=getPreferences(0).getInt("best",0); p.setTypeface(Typeface.DEFAULT_BOLD); }

        void startGame(){ score=0; time=30; playing=true; move(); lastSecond=System.currentTimeMillis(); invalidate(); }
        void move(){ tx=40+rnd.nextFloat()*Math.max(1,getWidth()-120); ty=150+rnd.nextFloat()*Math.max(1,getHeight()-230); }
        void finish(){ playing=false; if(score>best){best=score; getPreferences(0).edit().putInt("best",best).apply();} invalidate(); }

        @Override protected void onDraw(Canvas c){
            c.drawColor(Color.rgb(12,20,34));
            p.setColor(Color.rgb(24,36,58)); c.drawRect(0,0,getWidth(),100,p);
            p.setTextSize(18); p.setColor(Color.LTGRAY);
            c.drawText("PONTOS",35,30,p); c.drawText("TEMPO",getWidth()/2-30,30,p); c.drawText("RECORDE",getWidth()-120,30,p);
            p.setTextSize(28); p.setColor(Color.WHITE);
            c.drawText(""+score,35,68,p); c.drawText(""+time,getWidth()/2-10,68,p); c.drawText(""+best,getWidth()-105,68,p);

            if(playing){
                p.setColor(Color.rgb(255,71,87)); c.drawCircle(tx,ty,38,p);
                p.setColor(Color.WHITE); c.drawCircle(tx,ty,27,p);
                p.setColor(Color.rgb(255,71,87)); c.drawCircle(tx,ty,14,p);
                long now=System.currentTimeMillis();
                if(now-lastSecond>=1000){ time--; lastSecond=now; if(time<=0) finish(); }
                postInvalidateDelayed(100);
            } else {
                p.setTextAlign(Paint.Align.CENTER); p.setTextSize(26); p.setColor(Color.WHITE);
                c.drawText(score==0 ? "Caça ao Alvo" : "Fim de jogo!",getWidth()/2,220,p);
                p.setTextSize(18); c.drawText("Toque no botão para jogar",getWidth()/2,255,p);
                p.setColor(Color.rgb(46,213,115)); c.drawRoundRect(getWidth()/2-120,300,getWidth()/2+120,370,18,18,p);
                p.setColor(Color.rgb(7,19,11)); p.setTextSize(20); c.drawText("JOGAR",getWidth()/2,344,p);
                p.setTextAlign(Paint.Align.LEFT);
            }
        }

        @Override public boolean onTouchEvent(android.view.MotionEvent e){
            if(e.getAction()!=MotionEvent.ACTION_DOWN) return true;
            float x=e.getX(),y=e.getY();
            if(!playing && x>getWidth()/2-120 && x<getWidth()/2+120 && y>300 && y<370){startGame(); return true;}
            if(playing && Math.hypot(x-tx,y-ty)<55){score+=10; move();}
            return true;
        }
    }
}